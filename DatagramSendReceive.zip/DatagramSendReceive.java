//import java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketException;
//import java.nio.ByteBuffer;
//import java.nio.CharBuffer;
import java.net.InetAddress;
import java.net.UnknownHostException;
  
// public class DatagramSendReceive {
//	 
//	 //ds;
//	 String str = "Welcome";
//	 // ip;
//	 
//	 public DatagramSendReceive(String name){
//		 
//		 str = name;
//	 }
//	 
//	 public void DatagramSend() throws Exception{
//		 
//		DatagramSocket	ds = new DatagramSocket();
//		InetAddress	ip = InetAddress.getLocalHost();
//		DatagramPacket dp = new DatagramPacket(str.getBytes(), str.length(), ip, 3636);
//		ds.send(dp);
//		ds.close();
//	}
//	 
//	 public void DatagramReceive() throws Exception{
//		 
//		 System.out.println("Method");
//		 DatagramSocket ds = new DatagramSocket(3636);//
//		 byte[] buf = new byte[1024];
//		 System.out.println(buf);
//		 DatagramPacket dp = new DatagramPacket(buf, 1024);
//		 System.out.println(dp);
//		 ds.receive(dp);
//		 String str = new String(dp.getData(), 0, dp.getLength() );//
//		 System.out.println(new String(dp.getData()));
//		 System.out.println(str);
//		 ds.close();
//		 
//	}
//	 
//	 public static void main(String[] args){
//		 
//		 DatagramSendReceive dr = new DatagramSendReceive("Actions");
//		 try {
//			dr.DatagramSend();
//			System.out.println("Hello");
//			 dr.DatagramReceive();//
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//	 }
//	 
//	 
//	 
// }


//Write a Java program that uses java.net.DatagramSocket which is able to send and receive 
//java.net.DatagramPackets. The content of the packets will be Strings. 
//Your class must be named DatagramSendReceive. 

public class DatagramSendReceive implements Runnable {

	//private DatagramPacket d = new DatagramPacket(null, 0, 0, null);
	//private DatagramSocket d = new DatagramSocket();
	
//	private String Ip = "";
//	private int Pn = 0;
	
	private InetAddress s = null;
	@SuppressWarnings("unused")
	private int Pn = 0;
	
	@SuppressWarnings("unused")
	private static Runnable target = null;
	//@SuppressWarnings("unused")
	private static String message = "";
	
	@SuppressWarnings("unused")
	private DatagramSocket s1 = null;
	
	@SuppressWarnings("unused")
	private DatagramPacket p1 = null;
	static InetAddress address;

	@SuppressWarnings("unused")
	public DatagramSendReceive(DatagramSocket s) {
		super();
		this.s1 = s;
		try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			@SuppressWarnings("resource")
			DatagramSocket s1 = new DatagramSocket(8888);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public DatagramSendReceive(String message){
		
		setName(message);
	}

	public DatagramSendReceive() {
		try {
			s1 = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
//	public void sp() throws IOException{ //DatagramPacket
//		
////		InetAddress	ip = InetAddress.getLocalHost();
////		
////		//To send
////		@SuppressWarnings("resource")
////		DatagramSocket ds = new DatagramSocket(); 
////		System.out.println(getName());
////		DatagramPacket dp = new DatagramPacket(getName().getBytes(), getName().length(), ip, 8080);
////		ds.send(dp);
//		
////		byte[] ar2 = {1,1,1,1,1,1,1,1};
////		
////		DatagramPacket s4 = new DatagramPacket(ar2, ar2.length, address, 8080);
////		
////		//s4.setPort(8080);
////		//s4.setAddress(address);
////		
////		return s4;
//		
//	}
//
//	public void RP(){ //DatagramPacket
//		
////		//To receive
////		 System.out.println("Success");
////		 DatagramSocket ds2 = new DatagramSocket(8080);
////		 byte[] buf = new byte[1024];
////		 System.out.println(buf);
////		 DatagramPacket dp2 = new DatagramPacket(buf, 1024);
////		 System.out.println(dp);
////		// System.out.println(new String(dp.getData()));
////		 ds.receive(dp);
////		// System.out.println(ds);
////		 String str = new String(dp.getData(), 0, dp.getLength() );//
////		 System.out.println(new String(dp.getData()));
////		 System.out.println(str);
////		 ds.close();
//	
////	byte[] ar = {1,1,1,1,1,1,1,1};
////	
////	DatagramPacket s3 = new DatagramPacket(ar,ar.length); //ar,ar.length
////	s3.setPort(8080);
////	s3.setAddress(address);
////	
//////	byte[] ar2 = s3.getData();
//////	
//////	String gr = "";
//////	
//////	for(int i = 0; i < 8; i++){
//////	
//////		gr = gr + ar2[i];
//////	
//////	}
//////	
//////	int charCode = Integer.parseInt(gr, 2);
//////	
//////	String str = new Character((char)charCode).toString();
//////	
//////	System.out.println( ar2.toString() );
//////	System.out.println( gr );
//////	System.out.println( str);
////	
////	return s3;
//	
//	}
	
	//@Override
	//@SuppressWarnings("unused")
	
	
	
	@SuppressWarnings("unused")
	public void run(){ //Dont forget about this
		
		System.out.println("Thread is working");
		
		String Ip = "127.0.0.1"; //Receiver's Ip; It could be any IP address
		
		InetAddress adr = null;
		
		try {
			
			adr = InetAddress.getByName(Ip);
		
		} catch (UnknownHostException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		message = "This is a test"; //Sent Message
		
		DatagramSocket ds1 = null; //Receiver Socket
		
		try {
			
			ds1 = new DatagramSocket();
			
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Receiver
		
		int Pn1 = ds1.getLocalPort(); //Receiver_Port, The Port of the sending end
		
		DatagramSocket ds2 = null;//Sender Socket
		
		try {
			
			ds2 = new DatagramSocket();
		
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Sender
		
		int Pn2 = ds2.getLocalPort(); //Sender_Port, The Port of the receiving end
		
		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(), getMessage().length(),adr, Pn1);//Sender Packet
	
		ds2.connect(adr,Pn1);//adr could be the IP address of another computer
		
		try {
			
			ds2.send(dp1);
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
		
		try {
			
			ds1.receive(dp2); //To Store the receiving information
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String reme = new String(dp2.getData(), 0, dp2.getLength()) + ", from the IP address: "
				+ dp2.getAddress() + ", and from port: " + dp2.getPort();
				     
		System.out.println(reme); //Received Message

//		DatagramSendReceive d = new DatagramSendReceive();
		
		
//		try {
//			d.socket_builder();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		try {
//			d.socket_B();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	
//		while(true){
//			
//			System.out.println("Waiting for message");
//			System.out.print("Message Received");
//			
//		}
		
		//To receive
		// System.out.println("Success");
		
//		DatagramSocket ds2;
//		try {
//			InetAddress adr = InetAddress.getByName("192.168.1.160");
//			ds2 = new DatagramSocket(63000,adr);
//			byte[] buf = new byte[1024];
//			// System.out.println(buf);
//			 DatagramPacket dp2 = new DatagramPacket(buf, 1024);
//			// System.out.println(dp2);
//			// System.out.println(new String(dp.getData()));
//			 ds2.receive(dp2);
//			// System.out.println(ds);
//			// String str = new String(dp2.getData(), 0, dp2.getLength() );//
//			// System.out.println(new String(dp2.getData()));
//			// System.out.println(str);
//			 ds2.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		 
		
	}
	
	@SuppressWarnings("resource")
	public int socket_builder() throws IOException{ //Dont forget about this
		
		//String Ip = "127.0.0.1";
		//int Pn = 5050;
		
		//InetAddress adr = InetAddress.getByName(Ip);
		//To send
		DatagramSocket ds = new DatagramSocket(); //Pn
		int Pn1 = ds.getLocalPort();
		//ds.connect(adr, Pn);
		message = "Message Sent";
		//DatagramPacket dp = new DatagramPacket(getName().getBytes(), getName().length(),adr, Pn1);//ip, 8080
		//ds.send(dp);
		//Pn = Pn1;
		//s = adr;
		
		
		return Pn1;
	}
	
	@SuppressWarnings({ "resource" })
	public void socket_B() throws IOException{
	    
		//String Ip = "127.0.0.1";

		InetAddress adr = s;//InetAddress.getByName(Pn);
		DatagramSocket ds = new DatagramSocket(); //Pn
		
		int Pn = ds.getLocalPort();
		System.out.println(Pn);
		System.out.println("Server started");
		//DatagramSocket ds1 = new DatagramSocket(Pn);
		ds.connect(adr, Pn);
		
		message = "Message Received";
	    DatagramPacket dgp = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
		
		ds.receive(dgp);
		
		System.out.println(dgp.getAddress());
		System.out.println(dgp.getPort());
		
		String reme = new String(dgp.getData(), 0, dgp.getLength()) + ", from the IP address: "
		+ dgp.getAddress() + ", and from port: " + dgp.getPort();
		     
		System.out.println(reme);

	}
	
	public static void main(String[] args) throws IOException {
		
		DatagramSendReceive r = new DatagramSendReceive();
		Thread t1 = new Thread(r);
		t1.start();
		
//		String Ip = "127.0.0.1";
//		
//		InetAddress adr = InetAddress.getByName(Ip);
//		
//		message = "This is a test";
//		
//		DatagramSocket ds1 = new DatagramSocket(); //Receiver
//		int Pn1 = ds1.getLocalPort(); //Receiver_Port
//		
//		DatagramSocket ds2 = new DatagramSocket(); //Sender
//		int Pn2 = ds2.getLocalPort(); //Sender_Port
//		
//		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(), getMessage().length(),adr, Pn1);//Sender Packet
//	
//		ds2.connect(adr,Pn1);
//		
//		ds2.send(dp1);
//		
//		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
//		
//		ds1.receive(dp2);
//		
//		String reme = new String(dp2.getData(), 0, dp2.getLength()) + ", from the IP address: "
//				+ dp2.getAddress() + ", and from port: " + dp2.getPort();
//				     
//				System.out.println(reme);

		
		//run();
		//InetAddress	ip = ; //InetAddress.getLocalHost(); //148.84.130.77
		//InetAddress addr = InetAddress.getByName("127.0.0.1");
		
//		byte[] ip = new byte[]{(byte) 172, 20, (byte) 10, 3};
//		InetAddress adr = InetAddress.getByAddress(ip);
		
		//InetAddress adr = InetAddress.getByName("192.168.1.100");
		
		//InetAddress adr2 = (InetAddress) (adr.toString()).substring(1, (adr.toString()).length());
		//System.out.println(adr.toString());
		
		
		
		
//		try {
//			
//			//To send
//			DatagramSocket ds = new DatagramSocket(63000); 
//			ds.connect(adr, 63000);
//			name = "Back";
//			//System.out.println(getName());
//			DatagramPacket dp = new DatagramPacket(getName().getBytes(), getName().length(),adr, 63000);//ip, 8080
//			ds.send(dp);
//			//((Runnable) ds).run();
//			//ds.close();
//			
////			//To receive
//			 System.out.println("Success");
////			 DatagramSocket ds2 = new DatagramSocket(8080);
////			 byte[] buf = new byte[1024];
////			 System.out.println(buf);
////			 DatagramPacket dp2 = new DatagramPacket(buf, 1024);
////			 System.out.println(dp);
////			// System.out.println(new String(dp.getData()));
////			 ds.receive(dp);
////			// System.out.println(ds);
////			 String str = new String(dp.getData(), 0, dp.getLength() );//
////			 System.out.println(new String(dp.getData()));
////			 System.out.println(str);
////			 ds.close();
//			
//			
//		
//		} catch (SocketException e) {
//			
//			// TODO Auto-generated catch block
//			
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}

	public static String getMessage() {
		return message;
	}

	@SuppressWarnings("static-access")
	public void setName(String m) {
		this.message = m;
	}

	
	
}
	

