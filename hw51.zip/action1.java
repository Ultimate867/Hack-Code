//import java.awt.BorderLayout;
//import java.awt.Container;
//import java.awt.TextArea;
//import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
//import java.net.SocketException;
//import java.util.Scanner;


import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JPanel;

public class action1 extends DatagramSendReceive implements ActionListener,
		Runnable {

	// private TextField myTextField;
	// private TextArea myTextArea;

	private DatagramSocket DS;
	@SuppressWarnings("unused")
	private static String message = "";
	
	private InetAddress Ip;
	@SuppressWarnings("unused")
	private int SPort;
	
	public DatagramSocket getDS() {
		return DS;
	}

	public void setDS(DatagramSocket dS) {
		DS = dS;
	}

	public InetAddress getIp() {
		return Ip;
	}

	public void setIp(InetAddress ip) {
		Ip = ip;
	}

	public int getSPort() {
		return Port;
	}

	public void setSPort(int port) {
		Port = port;
	}





	private String M = " ";
	
	public void send(String d) {

		String Ip = "127.0.0.1"; // Receiver's Ip; It could be any IP address

		InetAddress adr = null;

		try {

			adr = InetAddress.getByName(Ip);

		} catch (UnknownHostException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		M = d; // Sent Message

		// DatagramSocket ds1 = null; // Receiver Socket
		//
		// try {
		//
		// ds1 = new DatagramSocket();
		//
		// } catch (SocketException e) {
		//
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } // Receiver
		//
		// int Pn1 = 64000; // Receiver_Port, The Port of the sending
		// end

		DatagramSocket ds2 = null;// Sender Socket

		try {

			ds2 = new DatagramSocket(50000);/////////

		} catch (SocketException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Sender
		
		System.out.println(ds2.isBound() + "ESD");/////

		int Pn2 = 43000; // Sender_Port, The Port of the receiving
										// end

		DatagramPacket dp1 = new DatagramPacket(getM().getBytes(),
				getM().length(), adr, Pn2);// Sender Packet

		//ds2.connect(adr, Pn2);// adr could be the IP address of another computer

		try {

			ds2.send(dp1);

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println( getM() );

	}

	public String getM() {
		return M;
	}

	public void setM(String m) {
		M = m;
	}

	public void receive(){
		
		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(),
				getMessage().length());
		
		System.out.println("Waiting To Receive");

		//System.out.println(DS.isBound());
		
	while(true){
		
		try {
			
			DS.receive(dp2);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("There's an error");
			e.printStackTrace();
		} // To Store the receiving information
		
		//System.out.println("Working Here");

		String reme = new String(dp2.getData(), 0, dp2.getLength())
				+ ", from the IP address: " + dp2.getAddress()
				+ ", and from port: " + dp2.getPort();

		System.out.println(reme); // Received Message

//		 IP = dp2.getAddress();
//		 Port = dp2.getPort();
//		 System.out.println(dp2.getAddress());
//		 System.out.println(dp2.getPort());
//		 g = new String(dp2.getData(), 0, dp2.getLength());
//		 setG(g);
//		 System.out.println(g + " This is wrong");
		// return getG();
		}

	}

	@SuppressWarnings({ "static-access" })
	public void actionPerformed(ActionEvent e) {

		//DatagramSendReceive r = new DatagramSendReceive();

		action1 a = new action1();

		String d = "/127.0.0.1"; // Any IP
		int p = 5; // Any Port

		JFrame frame2 = new JFrame("IP: " + d + " Port: " + p);
		frame2.setVisible(true);
		frame2.setSize(400, 400);

		// this.myTextArea = new TextArea();
		//
		// frame2.add(myTextArea, BorderLayout.SOUTH);
		//
		// frame2.setVisible(true);

//		@SuppressWarnings("resource")
//		Scanner mr = new Scanner(System.in);
//		System.out.println("This is my reply: ");
//		String r1 = mr.next();
//		
//		M = r1;

		// myTextArea.append(r1);;

		// System.out.println(reply + " reply");

		//r.setMessage(r1);
		
		////////////
		
//		Thread t1 = new Thread();
//		t1.start();
		
		/////////////////
		
		//t1.setName("");
		
		//a.send(M);
		

//		try {
//			t1.sleep(800);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		;

		System.out.println(a.getG());
		System.out.println(a.getIP());
		System.out.println(a.getPort());

//		JLabel label = new JLabel("My reply is: " + r1 + " : "
//				+ " his/her reply is: " + a.getG());
//		JPanel panel = new JPanel();

		// this.myTextField = new TextField();
		//
		// myTextField.addActionListener((ActionListener) this);
		//
		// Container textFieldPanel = null;
		// panel.add(myTextField, BorderLayout.CENTER);

//		frame2.add(panel);
//		panel.add(label);

	}

	// if( !(a.getIP().toString() ).equals(d) || (a.getPort()) != p){
	//
	// System.out.println("New Window");
	//
	// DatagramSendReceive r11 = new DatagramSendReceive();
	//
	// action1 a1 = new action1();
	//
	// String d1 = "/127.0.0.1";
	//
	// JFrame frame21 = new JFrame("IP: " + a.getIP() + " Port: " +
	// a.getPort());
	// frame21.setVisible(true);
	// frame21.setSize(400,400);
	//
	// @SuppressWarnings("resource")
	// Scanner mr1 = new Scanner(System.in);
	// System.out.println("This is my reply: ");
	// String reply1 = mr1.next();
	//
	// r11.setMessage(reply1);
	//
	// Thread t11 = new Thread(r11);
	// t11.start();
	// try {
	// t11.sleep(78);
	// } catch (InterruptedException e1) {
	// // TODO Auto-generated catch block
	// e1.printStackTrace();
	// };
	//
	// System.out.println(a.getG());
	// System.out.println(a.getIP());
	// System.out.println(a.getPort());
	//
	// JLabel label1 = new JLabel(reply1 + " : " + a.getG() );
	// JPanel panel1 = new JPanel();
	// frame21.add(panel1);
	// panel1.add(label1);
	// }
	//
	// }

	public action1() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Thread is working");
		
		try {
			DS = new DatagramSocket(43000);/////
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("WORK1");
		
		//while (true) {
			System.out.println("WORK2");
			receive();
			//System.out.println("WORK3");
		//}
	}

}