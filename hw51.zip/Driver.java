//import java.awt.BorderLayout;
//import java.awt.TextArea;
//import java.awt.TextField;
//import java.awt.event.ActionListener;
//import java.awt.event.WindowAdapter;
//import java.awt.event.WindowEvent;
//import java.io.IOException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
//import java.net.InetAddress;
//import java.net.InetAddress;

import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("unused")
public class Driver extends action1 implements Runnable{ 
//	public Driver(DatagramSocket sendSocket, InetAddress otherIP, int otherPort) {
//		super(sendSocket, otherIP, otherPort);
//		// TODO Auto-generated constructor stub
//	}
//
//	//private static final ActionListener ActionListener = null;
//extends ChatFrame implements Runnable{

//	public Driver(DatagramSocket sendSocket, InetAddress otherIP, int otherPort) {
//		super(sendSocket, otherIP, otherPort);
//		// TODO Auto-generated constructor stub
//	}
//
//
//	@SuppressWarnings({ "static-access", "unused" })
//	public static void main(String[] args) throws IOException {
//		
//		DatagramSocket t = new DatagramSocket();
//		int p = 43000;
//		String d = "127.0.0.1";
//		InetAddress f = null;
//		f.getByName(d);
//		
//		Driver r = new Driver(t, f, p);
//		
//		
//		// r.ChatFrame(t,d,p);
	
	//@SuppressWarnings("null")
	
	//private static TextField myTextField;
	//@SuppressWarnings("null")
	
	private String message = " ";
	
	@SuppressWarnings("resource")
	public void send(String d) {

		String Ip = "127.0.0.1"; // Receiver's Ip; It could be any IP address

		InetAddress adr = null;

		try {

			adr = InetAddress.getByName(Ip);

		} catch (UnknownHostException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		message = d; // Sent Message

		DatagramSocket ds2 = null;// Sender Socket

		try {

			ds2 = new DatagramSocket(50000);//////

		} catch (SocketException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Sender

		int Pn2 = 43000; // Sender_Port, The Port of the receiving
										// end

		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(),
				getMessage().length(), adr, Pn2);// Sender Packet

		//ds2.connect(adr, Pn2);// adr could be the IP address of another computer

		while(true){
		
		
		try {

			ds2.send(dp1);////

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}

	}

	public String getmessage() {
		return message;
	}

	public void setmessage(String message) {
		this.message = message;
	}

	public static void main(String[] args){
		
		action1 a = new action1();
		Driver a2 = new Driver();
		
		//while(true){
		
		Thread s = new Thread(a);
		s.start();
		
		
		Thread s2 = new Thread(a2);
		s2.start();
		
		
		
		//a.send("Hello");/////
		
	//	}
		
		//a.send("Hello");
		
//		  //
//		  TextField myTextField;
//		  myTextField = new TextField();
//
//			
//			myTextField.addActionListener(null );
//
//			Container textFieldPanel = null;
//			textFieldPanel.add(myTextField, BorderLayout.CENTER);
//			
//			//
//		  TextField myTestField = new TextField();
//
//		 
//		myTextField.addActionListener((ActionListener) );
//
//		  Container textFieldPanel = null;
//		textFieldPanel.add(myTextField, BorderLayout.CENTER);
		
		////////////////////////////////
		
//		  JFrame frame = new JFrame("Message Application"); 
//		  frame.setVisible(true);
//		  frame.setSize(500,200);
//		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		  
//		  JPanel panel = new JPanel();
//		  frame.add(panel);
//		  JButton button = new JButton("Reply");
//		  panel.add(button);
//		  button.addActionListener (new action1());
//
//		  JButton button2 = new JButton("Close");
//		  panel.add(button2);
//		  button2.addActionListener (new action2()); 
		}


	@Override
	public void run() {
		
		//while(true){
		
		send("Message");
		
		//}
		
	}
	}
	