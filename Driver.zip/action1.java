import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class action1 extends DatagramSendReceive implements ActionListener  { 
		
		@SuppressWarnings({ "static-access", "unused" })
		public void actionPerformed (ActionEvent e) {   
			  
			DatagramSendReceive r = new DatagramSendReceive();
			
			action1 a = new action1();
			
			String d = "/127.0.0.1"; //Any IP
			int p = 5; //Any Port
			
			JFrame frame2 = new JFrame("IP: " + d + " Port: " + p);
		    frame2.setVisible(true);
		    frame2.setSize(400,400);
		    
		    @SuppressWarnings("resource")
			Scanner mr = new Scanner(System.in);
			System.out.println("This is my reply: ");
			String reply = mr.next();
			
			r.setMessage(reply);
			
			Thread t1 = new Thread(r);
			t1.start();
			try {
				t1.sleep(78);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			};
			
			System.out.println(a.getG());
			System.out.println(a.getIP());
			System.out.println(a.getPort());
			
			JLabel label = new JLabel("My reply is: " + reply + " : " + " his/her reply is: " + a.getG() ); 
		    JPanel panel = new JPanel();
		    frame2.add(panel);
		    panel.add(label);    
		    
		    if( !(a.getIP().toString() ).equals(d) || (a.getPort()) != p){
		    	
		    	System.out.println("New Window");
		    	
		    	DatagramSendReceive r1 = new DatagramSendReceive();
				
				action1 a1 = new action1();
				
				String d1 = "/127.0.0.1";
				
				JFrame frame21 = new JFrame("IP: " + a.getIP() + " Port: " + a.getPort());
			    frame21.setVisible(true);
			    frame21.setSize(400,400);
			    
			    @SuppressWarnings("resource")
				Scanner mr1 = new Scanner(System.in);
				System.out.println("This is my reply: ");
				String reply1 = mr1.next();
				
				r1.setMessage(reply1);
		
				Thread t11 = new Thread(r1);
				t11.start();
				try {
					t11.sleep(78);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				};
				
				System.out.println(a.getG());
				System.out.println(a.getIP());
				System.out.println(a.getPort());
				
				JLabel label1 = new JLabel(reply1 + " : " + a.getG() ); 
			    JPanel panel1 = new JPanel();
			    frame21.add(panel1);
			    panel1.add(label1);     
		    }
		    
		}

		public action1() {
			super();
			// TODO Auto-generated constructor stub
		}

}

		
