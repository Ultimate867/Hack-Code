//import java.awt.BorderLayout;
//import java.awt.TextArea;
//import java.awt.TextField;
//import java.awt.event.ActionListener;
//import java.awt.event.WindowAdapter;
//import java.awt.event.WindowEvent;
//import java.io.IOException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
//import java.net.InetAddress;
//import java.net.InetAddress;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("unused")
public class Driver extends action1 implements Runnable{ 
	
	private String message = " ";
	private InetAddress ia;
	private int p;
	
	private static DatagramSocket DS;
	
//	public Driver(DatagramSocket dS) {
//		super();
//		DS = dS;
//	}

	public InetAddress getIa() {
		return ia;
	}

	public void setIa(InetAddress ia) {
		this.ia = ia;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	//@SuppressWarnings("resource")
	//@SuppressWarnings({ "resource" })
	public void send(String d, InetAddress ia, int port) { //Changed
		
		//byte[] b = new byte[1024];
		
		action1 s = new action1();
		
		System.out.println( d + " for the send method in the Driver");
		System.out.println( ia + " for the send method in the Driver");
		System.out.println( port + " for the send method in the Driver");
		

//		String Ip = ia.toString(); // Receiver's Ip; It could be any IP address
//		System.out.println(Ip + " t from the send method in Driver");
//
//		InetAddress adr = null;
//
//		try {
//
//			adr = InetAddress.getByName(Ip);
//
//		} catch (UnknownHostException e) {
//
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		System.out.println(adr + " as from the send method in Driver");

		message = d; // Sent Message

//		//@SuppressWarnings("resource")
//		DatagramSocket ds2 = null;
//		try {
//			ds2 = new DatagramSocket(64000);//Something Wrong
//		} catch (SocketException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}// Sender Socket

		//ds2 = getDS();
		
	//System.out.println( ds2.getPort() + " is the port of the sending socket");//Something Wrong
	//System.out.println( ds2.getInetAddress());

		//int Pn2 = 43000; // Sender_Port, The Port of the receiving
										// end

		//DatagramPacket dp1 = new DatagramPacket(b,
		//		1024, adr, port);// Sender Packet //Changed
		
		DatagramPacket dp1 = new DatagramPacket(getmessage().getBytes(),
				getmessage().length(), ia, port);// Sender Packet //Changed
		
		
		
//		String reme = new String(dp1.getData())
//		+ ", from the IP address: " + dp1.getAddress().getHostAddress()
//		+ ", and from port: " + dp1.getPort();
//		
//		System.out.println("Print reme");
//		System.out.println(reme);
//		System.out.println("reme result");


//	while(true){
		
		
		try {

			DS.send(dp1);////

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//	}

	}
	
	public void receive() {
		
		byte[] r = new byte[1024];

		DatagramPacket dp2 = new DatagramPacket(r,
				r.length);////////
		
		while(true) {

			try {
				
				System.out.println("Waiting To Receive.....");
				
				//DS = new DatagramSocket(64000);

				DS.receive(dp2);///

			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("There's an error");
				e.printStackTrace();
			} // To Store the receiving information

			InetAddress fromAddress = dp2.getAddress();
			int fromPort = dp2.getPort();
			
			System.out.println("Message From " + fromAddress.getHostAddress());
			System.out.println("Port         " + fromPort);
			
			String reme = new String(dp2.getData())
					+ ", from the IP address: " + dp2.getAddress().getHostAddress()
					+ ", and from port: " + dp2.getPort();
			
		//	String reme = new String(dp2.getData(), 0, dp2.getLength())
		//	+ ", from the IP address: " + dp2.getAddress()
		//	+ ", and from port: " + dp2.getPort();


			System.out.println(reme); // Received Message

//			Ip = dp2.getAddress();
//			Port = dp2.getPort();
//			System.out.println(dp2.getAddress());
//			System.out.println(dp2.getPort());
//			g = new String(dp2.getData(), 0, dp2.getLength());
//			setG(g);
//			System.out.println(g);

			// if(Ip != null && Port != 0){
			//
			// @SuppressWarnings("resource")
			// Scanner mr = new Scanner(System.in);
			// System.out.println("This is my reply: ");
			// String r1 = mr.next();
			//
			// Driver answer = new Driver();
			//
			// answer.send(r1, Ip, Port);
			//
			// }
		}

	}

	public String getmessage() {
		return message;
	}

	public void setmessage(String message) {
		this.message = message;
	}

	public static void main(String[] args){
		
		try {
			DS = new DatagramSocket(45000);///
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		action1 a = new action1();
		Driver a2 = new Driver();
		
		//while(true){
		
		//Thread s = new Thread(a);
		//s.start();
		
		Thread s2 = new Thread(a2);
		s2.start();
		
		a2.receive();///
		
//		  JFrame frame = new JFrame("Message Application"); 
//		  frame.setVisible(true);
//		  frame.setSize(500,200);
//		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		  
//		  JPanel panel = new JPanel();
//		  frame.add(panel);
//		  JButton button = new JButton("Reply");
//		  panel.add(button);
//		  button.addActionListener (new action1());
//
//		  JButton button2 = new JButton("Close");
//		  panel.add(button2);
//		  button2.addActionListener (new action2()); 
	}

	@Override
	public void run() {
		
		String r = "Junior:Contact";
		p = 64000;
		String g = "192.168.1.115";
		
		try {
			ia = InetAddress.getByName(g);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(r + " for the run method in the Driver");
		System.out.println(ia + " for the run method in the Driver");
		System.out.println(p + " for the run method in the Driver");
		
		send(r, ia, p);
	}
}
	