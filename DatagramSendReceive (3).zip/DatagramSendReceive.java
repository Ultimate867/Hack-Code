//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketException;
import java.net.InetAddress;
import java.net.UnknownHostException;
//import java.util.Scanner;
//import java.util.Scanner;
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JPanel;

public class DatagramSendReceive  {

	// @SuppressWarnings("unused")
	private static InetAddress IP = null;

	static String g;
	// @SuppressWarnings("unused")
	static int Port;

	private String name = " ";

	// @SuppressWarnings("unused")
	// private static Runnable target = null;
	// @SuppressWarnings("unused")
	private static String message = "";

	@SuppressWarnings("unused")
	private DatagramSocket s1 = null;

	public static String getG() {
		return g;
	}

	public static void setG(String g) {
		DatagramSendReceive.g = g;
	}

	@SuppressWarnings("unused")
	private DatagramPacket p1 = null;
	static InetAddress address;

	@SuppressWarnings("unused")
	public DatagramSendReceive(DatagramSocket s) {
		super();
		this.s1 = s;
		try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			@SuppressWarnings("resource")
			DatagramSocket s1 = new DatagramSocket(8888);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public DatagramSendReceive(String message) {

		setName(message);
	}

	public DatagramSendReceive() {
		super();
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("resource")
	public void run(String d) throws IOException { // Dont forget about this

		// DatagramSendReceive s3 = new DatagramSendReceive();

		System.out.println("Thread is working");

		String Ip = "192.168.1.100"; // Receiver's Ip; It could be any IP
										// address

		InetAddress adr = null;

		try {

			adr = InetAddress.getByName(Ip);

		} catch (UnknownHostException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Scanner mr = new Scanner(System.in);
		// System.out.println("Name of person: ");
		// name = mr.next();
		// System.out.println(name);

		message = " ???? " + d;// + name; // Sent Message

		DatagramSocket ds1 = null; // Receiver Socket

		// ds1.setBroadcast(true);

		try {
			ds1 = new DatagramSocket();
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// int Pn1 = ds1.getLocalPort(); //Receiver_Port, The Port of the
		// sending end//43000

		DatagramSocket ds2 = null;

		try {
			ds2 = new DatagramSocket(43000); // 43000
			// ds2 = new DatagramSocket();
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		;// Sender Socket

		// Thread sam = new Thread (s3);
		// sam.start();

		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(),
				getMessage().length(), adr, 64000);// Sender Packet // adr could
													// be
													// InetAddress.getByName("255.255.255.255"),

		// ds2.connect(adr, 64000);// adr could be the IP address of another
		// computer

		// ds2.setBroadcast(true);

		try {

			ds2.send(dp1);
			// ds2.close();
			// ds2.send(reply2);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(),
				getMessage().length());// buff, buff.length

		while (true) {

			ds1.receive(dp2); // To Store the receiving information

			String reme = new String(dp2.getData(), 0, dp2.getLength())
					+ ", from the IP address: " + dp2.getAddress()
					+ ", and from port: " + dp2.getPort();

			// ds1.getBroadcast();

			System.out.println("You have received info: " + reme); // Received
																	// Message

			IP = dp2.getAddress();
			Port = dp2.getPort();
			System.out.println(IP);
			System.out.println(Port);
			g = new String(dp2.getData(), 0, dp2.getLength());
			setG(g);
		}

	}

	public String getName() {
		return name;
	}

	public static InetAddress getIP() {
		return IP;
	}

	public static void setIP(InetAddress s) {
		DatagramSendReceive.IP = s;
	}

	public static int getPort() {
		return Port;
	}

	public static void setPort(int port) {
		Port = port;
	}

	public static void setMessage(String message) {
		DatagramSendReceive.message = message;
	}

	// @SuppressWarnings("resource")
	// public int socket_builder() throws IOException{ //Dont forget about this
	//
	// //String Ip = "127.0.0.1";
	// //int Pn = 5050;
	//
	// //InetAddress adr = InetAddress.getByName(Ip);
	// //To send
	// DatagramSocket ds = new DatagramSocket(); //Pn
	// int Pn1 = ds.getLocalPort();
	// //ds.connect(adr, Pn);
	// message = "Message Sent";
	// //DatagramPacket dp = new DatagramPacket(getName().getBytes(),
	// getName().length(),adr, Pn1);//ip, 8080
	// //ds.send(dp);
	// //Pn = Pn1;
	// //s = adr;
	//
	//
	// return Pn1;
	// }
	//
	// @SuppressWarnings({ "resource" })
	// public void socket_B() throws IOException{
	//
	// InetAddress adr = s;//InetAddress.getByName(Pn)
	// DatagramSocket ds = new DatagramSocket(); //Pn
	//
	//
	// int Pn = ds.getLocalPort();
	// System.out.println(Pn);
	// System.out.println("Server started");
	// //DatagramSocket ds1 = new DatagramSocket(Pn);
	// ds.connect(adr, Pn);
	//
	// message = "Message Received";
	// DatagramPacket dgp = new DatagramPacket(getMessage().getBytes(),
	// getMessage().length());//buff, buff.length
	//
	// ds.receive(dgp);
	//
	// System.out.println(dgp.getAddress());
	// System.out.println(dgp.getPort());
	//
	// String reme = new String(dgp.getData(), 0, dgp.getLength()) +
	// ", from the IP address: "
	// + dgp.getAddress() + ", and from port: " + dgp.getPort();
	//
	// System.out.println(reme);
	//
	// }
	//
	
	
//	// @SuppressWarnings("unused")
//	public void WindowMaker(InetAddress a) {
//
//		String s = a.toString();
//
//		JFrame frame = new JFrame(s);
//		frame.setVisible(true);
//		frame.setSize(400, 100);
//
//		JLabel label = new JLabel(a.toString());
//		JPanel panel = new JPanel();
//		frame.add(panel);
//		panel.add(label);
//
//	}

	public void send(String d) {

		String Ip = "127.0.0.1"; // Receiver's Ip; It could be any IP address

		InetAddress adr = null;

		try {

			adr = InetAddress.getByName(Ip);

		} catch (UnknownHostException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		message = d; // Sent Message

		// DatagramSocket ds1 = null; // Receiver Socket
		//
		// try {
		//
		// ds1 = new DatagramSocket();
		//
		// } catch (SocketException e) {
		//
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } // Receiver
		//
		// int Pn1 = 64000; // Receiver_Port, The Port of the sending
		// end

		DatagramSocket ds2 = null;// Sender Socket

		try {

			ds2 = new DatagramSocket(50000);

		} catch (SocketException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Sender

		int Pn2 = 43000; // Sender_Port, The Port of the receiving
										// end

		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(),
				getMessage().length(), adr, Pn2);// Sender Packet

		//ds2.connect(adr, Pn2);// adr could be the IP address of another computer

		try {

			ds2.send(dp1);

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println( getMessage() );

	}

//	//@SuppressWarnings("resource")
//	public void receive(DatagramSocket ds1) {
//		
//	//	System.out.println(ds1.toString());
//
////		DatagramSocket ds1 = null; // Receiver Socket
//
//		try {
//
//			ds1 = new DatagramSocket(); // 43000
//
//		} catch (SocketException e) {
//
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} 
//
//		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(),
//				getMessage().length());// buff, buff.length
//
//		//while (true) {
//
//			try {
//				ds1.receive(dp2);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} // To Store the receiving information
//
//			String reme = new String(dp2.getData(), 0, dp2.getLength())
//					+ ", from the IP address: " + dp2.getAddress()
//					+ ", and from port: " + dp2.getPort();
//
//			System.out.println(reme); // Received Message
//			//ds1.close();
//
////			IP = dp2.getAddress();
////			Port = dp2.getPort();
////			System.out.println(IP);
////			System.out.println(Port);
////			g = new String(dp2.getData(), 0, dp2.getLength());
////			setG(g);
////			System.out.println(g + " This is wrong");
//			// return getG();
//
//	//	}
//
//	}

	// public static void main(String[] args) throws IOException {
	//
	// // DatagramSendReceive r2 = new DatagramSendReceive();
	// // Thread t2 = new Thread(r2);
	// // t2.start();
	//
	// // DatagramSendReceive r = new DatagramSendReceive();
	// // String d = "127.0.0.1";
	// // s = InetAddress.getByName(d);
	// //
	// // Scanner mr = new Scanner(System.in);
	// // System.out.println("IP address: ");
	// // String reply = mr.next();
	// // System.out.println(g);
	// //
	// // if(! s.equals(reply) )
	// //
	// // s = InetAddress.getByName(reply);
	// // r.WindowMaker(s);
	// // }
	//
	// JFrame frame = new JFrame("Message Application");
	// frame.setVisible(true);
	// frame.setSize(500,200);
	// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//
	// JPanel panel = new JPanel();
	// frame.add(panel);
	// JButton button = new JButton("Reply");
	// panel.add(button);
	// // button.addActionListener (new Action1());
	//
	// JButton button2 = new JButton("Close");
	// panel.add(button2);
	// // button2.addActionListener (new Action2());
	// }
	//

	//
	// static class Action1 implements ActionListener {
	//
	// private DatagramSendReceive f;
	//
	// public Action1(DatagramSendReceive d) {
	//
	// this.f = d;
	// //return null;
	// }
	//
	// public Action1() {
	// // TODO Auto-generated constructor stub
	// }
	//
	// @SuppressWarnings("static-access")
	// public String GetMessages(){
	//
	// System.out.println(f.getG());
	// return f.getG();
	// }
	//
	// //@SuppressWarnings({ "static-access", "unused" })
	// public void actionPerformed (ActionEvent e) {
	//
	// DatagramSendReceive r = new DatagramSendReceive();
	//
	// Action1 r1 = Action1(r);
	//
	// String d = "192.168.1.104";
	//
	// // try {
	// // s = InetAddress.getByName(d);
	// // } catch (UnknownHostException e1) {
	// // // TODO Auto-generated catch block
	// // e1.printStackTrace();
	// // }
	//
	// JFrame frame2 = new JFrame(d);
	// frame2.setVisible(true);
	// frame2.setSize(200,200);
	//
	// @SuppressWarnings("resource")
	// Scanner mr = new Scanner(System.in);
	// System.out.println("This is my reply: ");
	// String reply = mr.next();
	//
	// // Scanner mr1 = new Scanner(System.in);
	// // System.out.println("Name: ");
	// // String reply1 = "????" + " " + mr.next();
	// //"##### name of person ##### ww.xx.yy.zz"
	// //title of the messaging window should be the name of the person you are
	// messaging plus their IP address.
	//
	// message = reply;
	//
	// Thread t1 = new Thread(r);
	// t1.start();
	//
	// //Thread t2 = new Thread(r);
	// //t2.start();
	//
	// //System.out.println( frame2.getTitle() );
	// //System.out.println(s + " " + "WHY" + " " + Port);
	//
	// //System.out.print( r1.GetMessages() );
	//
	// String f = r1.GetMessages();
	//
	// JLabel label = new JLabel(reply + " : " + f); //r.getG());
	// JPanel panel = new JPanel();
	// frame2.add(panel);
	// panel.add(label);
	//
	// }
	//
	//
	// private Action1 Action1(DatagramSendReceive r) {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// // @SuppressWarnings("unused")
	// // private Object Action11(DatagramSendReceive r) {
	// // // TODO Auto-generated method stub
	// // return null;
	// // }
	//
	// // private Action1 Action1(DatagramSendReceive r) {
	// // // TODO Auto-generated method stub
	// // return null;
	// // }
	// }

	// static class Action2 implements ActionListener {
	// public void actionPerformed (ActionEvent e) {
	//
	// System.exit(0);
	// // JFrame frame3 = new JFrame("Response");
	// // frame3.setVisible(true);
	// // frame3.setSize(200,200);
	// //
	// // JLabel label = new JLabel("Answer");
	// // JPanel panel = new JPanel();
	// // frame3.add(panel);
	// // panel.add(label);
	// }
	// }

	public static String getMessage() {
		return message;
	}

	public void setName(String name) {
		this.name = name;
	}

//	@Override
//	public void run() {
//		// TODO Auto-generated method stub
//
//		//DatagramSendReceive r = new DatagramSendReceive();
//
//		// try {
//		// run(message);
//		// } catch (IOException e) {
//		// // TODO Auto-generated catch block
//		// e.printStackTrace();
//		// }
//		
//		while(true){
//			
//			receive(DS);
//		
//		}
//		
//		
//
//	}
//
	public static void removeChatFrame(InetAddress otherIP, int otherPort) {
		// TODO Auto-generated method stub

	}


//public void run() {
//	// TODO Auto-generated method stub
//	
//}
}
