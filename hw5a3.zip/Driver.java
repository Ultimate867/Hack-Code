import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
//import java.util.Scanner;
import java.awt.BorderLayout;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
//import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Driver extends Action1 implements ActionListener, Runnable {

	private String message = " ";
	private static InetAddress ia;
	private int p;
	private TextField myTextField;
	private TextArea myTextArea; // new TextArea();
	private String MYM;
	private static Driver a2 = new Driver();
	private JPanel textFieldPanel; // new JPanel(new BorderLayout());
	private JButton sendButton; //JButton();
	private JFrame frame2;

	private static DatagramSocket DS;

	public InetAddress getIa() {
		return ia;
	}

	@SuppressWarnings("static-access")
	public void setIa(InetAddress ia) {
		this.ia = ia;
	}

	public static DatagramSocket getDS() {
		return DS;
	}

	public void setDS(DatagramSocket dS) {
		DS = dS;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}
	
	public void send(String d, InetAddress ia, int port) { // Changed

		message = d; // Sent Message

		DatagramPacket dp1 = new DatagramPacket(getmessage().getBytes(),
				getmessage().length(), ia, port);// Sender Packet //Changed

		try {

			DS.send(dp1);// //

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void receive() {

		byte[] r = new byte[1024];
		
		String[] a1 = new String[10];
		
		int[] aa = new int[10];
		
		InetAddress[] ab = new InetAddress[10];

		DatagramPacket dp2 = new DatagramPacket(r, r.length);
		
		int i = 0;

		while (true) {

			try {

				System.out.println("Waiting To Receive.....");

				DS.receive(dp2);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("There's an error");
				e.printStackTrace();
			} // To Store the receiving information
			
			InetAddress fromAddress = dp2.getAddress();
			int fromPort = dp2.getPort();
			String fromMessage = new String(dp2.getData());

			System.out.println("Message From " + fromAddress.getHostAddress());
			System.out.println("Port         " + fromPort);
			System.out.println("Message         " + fromMessage);

			String reme = new String(dp2.getData()) + ", from the IP address: "
					+ dp2.getAddress().getHostAddress() + ", and from port: "
					+ dp2.getPort();

			System.out.println(reme); // Received Message
			
			String s = "THEM: " + new String(dp2.getData());
			
			a1[i] = new String(dp2.getData());
			aa[i] = dp2.getPort();
			ab[i] = dp2.getAddress();
			
			System.out.println(a1[i]);
			System.out.println(aa[i]);
			System.out.println(ab[i]);
			
			i++;
	
			ia = dp2.getAddress();
			p = dp2.getPort();
			
			/////////////
			
			if(ab[i] == ab[i-1] && i != 0){
				System.out.println("HERE");
				System.out.println(ab[i]);
				System.out.println(ab[i-1]);
			}
			
			
			////////////////////
			//if(ab[i] != ab[i-1] && i != 0){

			//JFrame frame2 = new JFrame("IP: " + ia + " Port: " + p);//Remember
			
			frame2 = new JFrame("IP: " + ia + " Port: " + p);
		
			frame2.setVisible(true);
			frame2.setSize(400, 400);

			//textFieldPanel = new JPanel(new BorderLayout());
			
			//JPanel textFieldPanel = new JPanel(new BorderLayout());//Remember

			//myTextField = new TextField();//Remember
			
			myTextField.addActionListener((ActionListener) this);//(ActionListener) this
			
			//JOptionPane.showMessageDialog(frame2, myTextField.getText());

			textFieldPanel.add(myTextField, BorderLayout.CENTER);

			//myTextArea = new TextArea();
			
			//JScrollPane scrollPane = new JScrollPane(myTextArea);
			//content.add(scrollPane);
			myTextField.setText("");
			
			MYM = myTextField.getText();

			myTextArea.append(MYM);//s
			myTextArea.append(s);
		//	myTextArea.append("Force");
			
//			((DocumentEvent) myTextField).getDocument().addDocumentListener(new DocumentListener() {
//
//	            @Override
//	            public void insertUpdate(DocumentEvent de) {
//	            	
//	            	myTextArea.setText(myTextField.getText());
//	            }
//
//	            @Override
//	            public void removeUpdate(DocumentEvent de) {
//	            }
//
//	            @Override
//	            public void changedUpdate(DocumentEvent de) {
//	            }
//	        });
			
//			@SuppressWarnings("resource")
//			Scanner dr = new Scanner(System.in);
//			System.out.println("REPLY");
//			String de = dr.next();
//			myTextField.setText(de);

			frame2.add(myTextArea, BorderLayout.CENTER);

			frame2.setVisible(true);
			
//			myTextArea.setText(myTextField.getText());
//			
//			System.out.println(myTextArea.getText());
			
			//myTextField.setText("SA");
			
			//myTextArea.setText("Execute");
			
			//System.out.println(myTextArea.getText());
			
			//myTextArea.append(arg0);

			//sendButton = new JButton("Send");//Remember

			sendButton.addActionListener(a2);
			
			textFieldPanel.add(sendButton, BorderLayout.EAST);

			frame2.add(textFieldPanel, BorderLayout.SOUTH);
			
			}
		//}

	}

	public void actionPerformed(ActionEvent e) {

//		@SuppressWarnings("resource")
//		Scanner d = new Scanner(System.in);
//		System.out.println("REPLY: ");
//		String g = d.next();
		
		//while(!myTextField.getText().equals("ABORT")){
		
		message = myTextField.getText();
		
		myTextArea.append("\nME: " + message + "\n");//May need fixes
		//myTextArea.append("SAE");

		System.out.println("For the Driver method this is the message: " + message);
		System.out.println("For the Driver method this is the IP: " + ia);
		System.out.println("For the Driver method this is the port: " + p);
		
		//MYM = myTextField.getText();

		send(message, ia, p);
		
		//}
		
		//send(message, ia, p);
		//receive();

	}

	public Driver() {
		super();
		
		this.myTextField = new TextField();
		this.myTextArea = new TextArea();
		this.textFieldPanel = new JPanel();
		this.sendButton = new JButton();
		//this.frame2 = new JFrame("IP: " + ia + " Port: " + p);
	}

	public String getmessage() {
		return message;
	}

	public void setmessage(String message) {
		this.message = message;
	}

	public static void main(String[] args) {

		// JFrame frame = new JFrame("Message Application");
		// frame.setVisible(true);
		// frame.setSize(500,200);
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//
		// JPanel panel = new JPanel();
		// frame.add(panel);
		// JButton button = new JButton("Reply");
		// panel.add(button);
		// button.addActionListener (new Action1());
		//
		// JButton button2 = new JButton("Close");
		// panel.add(button2);
		// button2.addActionListener (new Action2());

		try {
			DS = new DatagramSocket(45000);// /
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//a2 = new Driver();

		Thread s2 = new Thread(a2);
		s2.start();

		//a2.receive();

	}

	@Override
	public void run() {

//		@SuppressWarnings("resource")
//		Scanner d = new Scanner(System.in);
//		System.out.println("REPLY: ");
		String r = "Contact";
		p = 45000;
		String g = "127.0.0.1";

		try {
			ia = InetAddress.getByName(g);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		send(r, ia, p);
		receive();
	}
}