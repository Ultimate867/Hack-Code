//import java.io.BufferedReader;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketException;
//import java.nio.ByteBuffer;
//import java.nio.CharBuffer;
import java.net.InetAddress;
import java.net.UnknownHostException;
//import java.util.Scanner;

import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
  


//Write a Java program that uses java.net.DatagramSocket which is able to send and receive 
//java.net.DatagramPackets. The content of the packets will be Strings. 
//Your class must be named DatagramSendReceive. 

public class DatagramSendReceive implements Runnable {
	
	private static InetAddress s = null;
	@SuppressWarnings("unused")
	private int Pn = 0;
	
	@SuppressWarnings("unused")
	private static Runnable target = null;
	//@SuppressWarnings("unused")
	private static String message = "";
	
	@SuppressWarnings("unused")
	private DatagramSocket s1 = null;
	
	@SuppressWarnings("unused")
	private DatagramPacket p1 = null;
	static InetAddress address;

	@SuppressWarnings("unused")
	public DatagramSendReceive(DatagramSocket s) {
		super();
		this.s1 = s;
		try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			@SuppressWarnings("resource")
			DatagramSocket s1 = new DatagramSocket(8888);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public DatagramSendReceive(String message){
		
		setName(message);
	}

	public DatagramSendReceive() {
		try {
			s1 = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	//@SuppressWarnings("unused")
	@SuppressWarnings("unused")
	public void run(){ //Dont forget about this
		
		System.out.println("Thread is working");
		
		String Ip = "127.0.0.1"; //Receiver's Ip; It could be any IP address
		
		InetAddress adr = null;
		
		try {
			
			adr = InetAddress.getByName(Ip);
		
		} catch (UnknownHostException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		message = "This is a test"; //Sent Message
		
		DatagramSocket ds1 = null; //Receiver Socket
//		
//		try {
//			
		try {
			ds1 = new DatagramSocket();
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//			
//		} catch (SocketException e) {
//			
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} //Receiver
		
		int Pn1 = ds1.getLocalPort(); //Receiver_Port, The Port of the sending end
		
		DatagramSocket ds2 = null;//Sender Socket
		
		try {
			
			ds2 = new DatagramSocket();
		
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Sender
		
		int Pn2 = ds2.getLocalPort(); //Sender_Port, The Port of the receiving end
		
		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(), getMessage().length(),adr, Pn1);//Sender Packet
	
		ds2.connect(adr,Pn1);//adr could be the IP address of another computer
		
		try {
			
			ds2.send(dp1);
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
		
		try {
			
			ds1.receive(dp2); //To Store the receiving information
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String reme = new String(dp2.getData(), 0, dp2.getLength()) + ", from the IP address: "
				+ dp2.getAddress() + ", and from port: " + dp2.getPort();
				     
		System.out.println(reme); //Received Message
		 
		
	}
	
	@SuppressWarnings("resource")
	public int socket_builder() throws IOException{ //Dont forget about this
		
		//String Ip = "127.0.0.1";
		//int Pn = 5050;
		
		//InetAddress adr = InetAddress.getByName(Ip);
		//To send
		DatagramSocket ds = new DatagramSocket(); //Pn
		int Pn1 = ds.getLocalPort();
		//ds.connect(adr, Pn);
		message = "Message Sent";
		//DatagramPacket dp = new DatagramPacket(getName().getBytes(), getName().length(),adr, Pn1);//ip, 8080
		//ds.send(dp);
		//Pn = Pn1;
		//s = adr;
		
		
		return Pn1;
	}
	
	@SuppressWarnings({ "resource" })
	public void socket_B() throws IOException{

		InetAddress adr = s;//InetAddress.getByName(Pn)
		DatagramSocket ds = new DatagramSocket(); //Pn
		
		
		int Pn = ds.getLocalPort();
		System.out.println(Pn);
		System.out.println("Server started");
		//DatagramSocket ds1 = new DatagramSocket(Pn);
		ds.connect(adr, Pn);
		
		message = "Message Received";
	    DatagramPacket dgp = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
		
		ds.receive(dgp);
		
		System.out.println(dgp.getAddress());
		System.out.println(dgp.getPort());
		
		String reme = new String(dgp.getData(), 0, dgp.getLength()) + ", from the IP address: "
		+ dgp.getAddress() + ", and from port: " + dgp.getPort();
		     
		System.out.println(reme);

	}
	
	//@SuppressWarnings("unused")
	public void WindowMaker(InetAddress a){
		
		String s = a.toString();
		
		JFrame frame = new JFrame(s);
	    frame.setVisible(true);
	    frame.setSize(400,100);

	    JLabel label = new JLabel("Answer");
	    JPanel panel = new JPanel();
	    frame.add(panel);
	    panel.add(label);
	    
//	    String d = "121.12.21.34";
//	    
//	    if( !s.equals(d) ){
//	    	
//	    	JFrame frame1 = new JFrame(s);
//		    frame.setVisible(true);
//		    frame.setSize(200,200);
//
//		    JLabel label1 = new JLabel("Answer");
//		    JPanel panel1 = new JPanel();
//		    frame.add(panel);
//		    panel.add(label);
//	    }
	}
	
	@SuppressWarnings("unused")
	public void send(String d){ 
		
		//System.out.println("Thread is working");
		
		String Ip = "127.0.0.1"; //Receiver's Ip; It could be any IP address
		
		InetAddress adr = null;
		
		try {
			
			adr = InetAddress.getByName(Ip);
		
		} catch (UnknownHostException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		message = d; //Sent Message
		
		DatagramSocket ds1 = null; //Receiver Socket
		
		try {
			
			ds1 = new DatagramSocket();
			
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Receiver
		
		int Pn1 = ds1.getLocalPort(); //Receiver_Port, The Port of the sending end
		
		DatagramSocket ds2 = null;//Sender Socket
		
		try {
			
			ds2 = new DatagramSocket();
		
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Sender
		
		int Pn2 = ds2.getLocalPort(); //Sender_Port, The Port of the receiving end
		
		DatagramPacket dp1 = new DatagramPacket(getMessage().getBytes(), getMessage().length(),adr, Pn1);//Sender Packet
	
		ds2.connect(adr,Pn1);//adr could be the IP address of another computer
		
		try {
			
			ds2.send(dp1);
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//dp1.getAddress();
		
		
	}
	
	public void receive(){
		
		DatagramSocket ds1 = null; //Receiver Socket
		
		try {
			
			ds1 = new DatagramSocket();
			
		} catch (SocketException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Recei
		
		DatagramPacket dp2 = new DatagramPacket(getMessage().getBytes(), getMessage().length());//buff, buff.length
		
		try {
			
			ds1.receive(dp2); //To Store the receiving information
		
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String reme = new String(dp2.getData(), 0, dp2.getLength()) + ", from the IP address: "
				+ dp2.getAddress() + ", and from port: " + dp2.getPort();
				     
		System.out.println(reme); //Received Message
	}
	
	//@SuppressWarnings("static-access")
	//@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		
		

		
//		
//		DatagramSendReceive r2 = new DatagramSendReceive();
//		Thread t2 = new Thread(r2);
//		t2.start();
		
//		DatagramSendReceive r = new DatagramSendReceive();
//		String d = "127.0.0.1";
//		s = InetAddress.getByName(d);
//		
//		Scanner mr = new Scanner(System.in);
//		System.out.println("IP address: ");
//		String reply = mr.next();
//		System.out.println(reply);
//		
//		if(! s.equals(reply) )
//		
//			s = InetAddress.getByName(reply);
//			r.WindowMaker(s);
//		}
		
		  JFrame frame = new JFrame("Message Application"); //Test is The IP address I'm communicating with
		  frame.setVisible(true);
		  frame.setSize(500,200);
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		  JPanel panel = new JPanel();
		  frame.add(panel);
		  JButton button = new JButton("Reply");
		  panel.add(button);
		  button.addActionListener (new Action1());

		  JButton button2 = new JButton("Close");
		  panel.add(button2);
		  button2.addActionListener (new Action2()); 
		}
		static class Action1 implements ActionListener {        
		  public void actionPerformed (ActionEvent e) {   
			  
			DatagramSendReceive r = new DatagramSendReceive();
			  
			String d = "127.0.0.1";
			
			JFrame frame2 = new JFrame(d);
		    frame2.setVisible(true);
		    frame2.setSize(200,200);
		    
		    @SuppressWarnings("resource")
			Scanner mr = new Scanner(System.in);
			System.out.println("This is my reply: ");
			String reply = mr.next();
	
			Thread t1 = new Thread(r);
			t1.start();
			
//			System.out.println( frame2.isFocused() );
//			System.out.println( frame2.isActive() );
//			System.out.println( frame2.getName() );
//			System.out.println( frame2.getTitle() );
//			System.out.println( frame2.getType());
			
		    JLabel label = new JLabel(reply);
		    JPanel panel = new JPanel();
		    frame2.add(panel);
		    panel.add(label);     
		    
		    
		 }
		}   
		
		static class Action2 implements ActionListener {        
		  public void actionPerformed (ActionEvent e) { 
			  
			  System.exit(0);
//		    JFrame frame3 = new JFrame("Response");
//		    frame3.setVisible(true);
//		    frame3.setSize(200,200);
//
//		    JLabel label = new JLabel("Answer");
//		    JPanel panel = new JPanel();
//		    frame3.add(panel);
//		    panel.add(label);
		  }
		}   
		

	public static String getMessage() {
		return message;
	}

	@SuppressWarnings("static-access")
	public void setName(String m) {
		this.message = m;
	}

	
	
}
	

