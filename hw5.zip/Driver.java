//import java.awt.BorderLayout;
//import java.awt.TextArea;
//import java.awt.TextField;
//import java.awt.event.ActionListener;
//import java.awt.event.WindowAdapter;
//import java.awt.event.WindowEvent;
//import java.io.IOException;
import java.net.DatagramSocket;
//import java.net.InetAddress;
//import java.net.InetAddress;

import java.net.InetAddress;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("unused")
public class Driver extends action1 implements Runnable{ 
//	public Driver(DatagramSocket sendSocket, InetAddress otherIP, int otherPort) {
//		super(sendSocket, otherIP, otherPort);
//		// TODO Auto-generated constructor stub
//	}
//
//	//private static final ActionListener ActionListener = null;
//extends ChatFrame implements Runnable{

//	public Driver(DatagramSocket sendSocket, InetAddress otherIP, int otherPort) {
//		super(sendSocket, otherIP, otherPort);
//		// TODO Auto-generated constructor stub
//	}
//
//
//	@SuppressWarnings({ "static-access", "unused" })
//	public static void main(String[] args) throws IOException {
//		
//		DatagramSocket t = new DatagramSocket();
//		int p = 43000;
//		String d = "127.0.0.1";
//		InetAddress f = null;
//		f.getByName(d);
//		
//		Driver r = new Driver(t, f, p);
//		
//		
//		// r.ChatFrame(t,d,p);
	
	//@SuppressWarnings("null")
	
	//private static TextField myTextField;
	//@SuppressWarnings("null")

	public static void main(String[] args){
		
		action1 a = new action1();
		
		Thread s = new Thread(a);
		s.start();
		
		a.send("Hello");
		//a.send("Hello");
		
//		  //
//		  TextField myTextField;
//		  myTextField = new TextField();
//
//			
//			myTextField.addActionListener(null );
//
//			Container textFieldPanel = null;
//			textFieldPanel.add(myTextField, BorderLayout.CENTER);
//			
//			//
//		  TextField myTestField = new TextField();
//
//		 
//		myTextField.addActionListener((ActionListener) );
//
//		  Container textFieldPanel = null;
//		textFieldPanel.add(myTextField, BorderLayout.CENTER);
		
		////////////////////////////////
		
//		  JFrame frame = new JFrame("Message Application"); 
//		  frame.setVisible(true);
//		  frame.setSize(500,200);
//		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		  
//		  JPanel panel = new JPanel();
//		  frame.add(panel);
//		  JButton button = new JButton("Reply");
//		  panel.add(button);
//		  button.addActionListener (new action1());
//
//		  JButton button2 = new JButton("Close");
//		  panel.add(button2);
//		  button2.addActionListener (new action2()); 
		}


//	@Override
//	public void run() {
//		// TODO Auto-generated method stub
//		
//	}
	}
	