import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("unused")
public class Driver extends Action1 implements ActionListener, Runnable {

	private String message = " ";
	private static InetAddress ia;
	private int p;
	private TextField myTextField;
	private TextArea myTextArea;
	
	private java.util.List<String> list;//Keep Windows
	
	//list.

	private static Driver a2;

	private static DatagramSocket DS;

	public InetAddress getIa() {
		return ia;
	}

	@SuppressWarnings("static-access")
	public void setIa(InetAddress ia) {
		this.ia = ia;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	// @SuppressWarnings("resource")
	// @SuppressWarnings({ "resource" })
	public void send(String d, InetAddress ia, int port) { // Changed

		//list
		// byte[] b = new byte[1024];

		// Action1 s = new Action1();

		// System.out.println( d + " for the send method in the Driver");
		// System.out.println( ia + " for the send method in the Driver");
		// System.out.println( port + " for the send method in the Driver");

		// String Ip = ia.toString(); // Receiver's Ip; It could be any IP
		// address
		// System.out.println(Ip + " t from the send method in Driver");
		//
		// InetAddress adr = null;
		//
		// try {
		//
		// adr = InetAddress.getByName(Ip);
		//
		// } catch (UnknownHostException e) {
		//
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// System.out.println(adr + " as from the send method in Driver");

		message = d; // Sent Message

		// //@SuppressWarnings("resource")
		// DatagramSocket ds2 = null;
		// try {
		// ds2 = new DatagramSocket(64000);//Something Wrong
		// } catch (SocketException e1) {
		// // TODO Auto-generated catch block
		// e1.printStackTrace();
		// }// Sender Socket

		// ds2 = getDS();

		// System.out.println( ds2.getPort() +
		// " is the port of the sending socket");//Something Wrong
		// System.out.println( ds2.getInetAddress());

		// int Pn2 = 43000; // Sender_Port, The Port of the receiving
		// end

		// DatagramPacket dp1 = new DatagramPacket(b,
		// 1024, adr, port);// Sender Packet //Changed

		DatagramPacket dp1 = new DatagramPacket(getmessage().getBytes(),
				getmessage().length(), ia, port);// Sender Packet //Changed

		// while(true){

		try {

			DS.send(dp1);// //

		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// return null;

		// }

	}

	public void receive() {

		byte[] r = new byte[1024];

		Driver r2 = new Driver();

		DatagramPacket dp2 = new DatagramPacket(r, r.length);

		while (true) {

			try {

				System.out.println("Waiting To Receive.....");

				DS.receive(dp2);// /

			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("There's an error");
				e.printStackTrace();
			} // To Store the receiving information

			InetAddress fromAddress = dp2.getAddress();
			int fromPort = dp2.getPort();
			String fromMessage = new String(dp2.getData());

			System.out.println("Message From " + fromAddress.getHostAddress());
			System.out.println("Port         " + fromPort);
			System.out.println("Message         " + fromMessage);

			String reme = new String(dp2.getData()) + ", from the IP address: "
					+ dp2.getAddress().getHostAddress() + ", and from port: "
					+ dp2.getPort();

			System.out.println(reme); // Received Message

			ia = dp2.getAddress();
			p = dp2.getPort();
			// message = "WHY";

			JFrame frame2 = new JFrame("IP: " + dp2.getAddress() + " Port: "
					+ dp2.getPort());
			frame2.setVisible(true);
			frame2.setSize(400, 400);

			// JLabel label1 = new JLabel("My reply" + fromMessage + fromPort);
			// JPanel panel1 = new JPanel();
			// frame2.add(panel1);
			// panel1.add(label1);
			//
			JPanel textFieldPanel = new JPanel(new BorderLayout());

			// create the TextField
			// set the action listener that gets called when you press Enter
			// add the TextField to the JPanel

			myTextField = new TextField();

			myTextField.addActionListener((ActionListener) this);

			textFieldPanel.add(myTextField, BorderLayout.CENTER);

			myTextArea = new TextArea();

			myTextArea.append("THEM: " + new String(dp2.getData()));
			myTextArea.append("THEM: ");

			frame2.add(myTextArea, BorderLayout.CENTER);

			frame2.setVisible(true);

			JButton sendButton = new JButton("Send");

			sendButton.addActionListener(a2);// send("D",ia,p)//(ActionListener)
												// this//new Action1(DS,
												// dp2.getAddress(),
												// dp2.getPort())

			textFieldPanel.add(sendButton, BorderLayout.EAST);

			frame2.add(textFieldPanel, BorderLayout.SOUTH);

			// Ip = dp2.getAddress();
			// Port = dp2.getPort();
			// System.out.println(dp2.getAddress());
			// System.out.println(dp2.getPort());
			// g = new String(dp2.getData(), 0, dp2.getLength());
			// setG(g);
			// System.out.println(g);

			// if(Ip != null && Port != 0){
			//
			// @SuppressWarnings("resource")
			// Scanner mr = new Scanner(System.in);
			// System.out.println("This is my reply: ");
			// String r1 = mr.next();
			//
			// Driver answer = new Driver();
			//
			// answer.send(r1, Ip, Port);
			//
			// }
		}

	}

	public void actionPerformed(ActionEvent e) {

		System.out.println("SAS");

		System.out.println("For the Driver method this is the message: "
				+ message);
		System.out.println("For the Driver method this is the IP: " + ia);
		System.out.println("For the Driver method this is the port: " + p);

		send(message, ia, p);

	}

	public String getmessage() {
		return message;
	}

	public void setmessage(String message) {
		this.message = message;
	}

	public static void main(String[] args) {

		// JFrame frame = new JFrame("Message Application");
		// frame.setVisible(true);
		// frame.setSize(500,200);
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//
		// JPanel panel = new JPanel();
		// frame.add(panel);
		// JButton button = new JButton("Reply");
		// panel.add(button);
		// button.addActionListener (new Action1());
		//
		// JButton button2 = new JButton("Close");
		// panel.add(button2);
		// button2.addActionListener (new Action2());
		
		//System.out.println(list.)

		try {
			DS = new DatagramSocket(45000);// /
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Action1 a = new Action1();
		a2 = new Driver();

		Thread s2 = new Thread(a2);
		s2.start();

		a2.receive();

	}

	@Override
	public void run() {

		String r = "Junior:Contact";
		p = 45000;
		String g = "127.0.0.1";

		try {
			ia = InetAddress.getByName(g);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// System.out.println(r + " for the run method in the Driver");
		// System.out.println(ia + " for the run method in the Driver");
		// System.out.println(p + " for the run method in the Driver");

		// for(int i = 0; i < 2; i++){

		send(r, ia, p);

		// }
	}
}
