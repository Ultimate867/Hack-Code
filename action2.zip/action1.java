import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.net.DatagramSocket;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class action1 extends DatagramSendReceive implements ActionListener  { 
	
			//@SuppressWarnings("unused")
			//private String message = " ";
			
//			private DatagramSendReceive f;
//			
//			public action1(DatagramSocket s, DatagramSendReceive f) {
//				super(s);
//				this.f = f;
//			}
//
//			public action1(DatagramSendReceive d) {
//				
//				this.f  = d;
//				//return null;
//			}
//
//			public action1(Object r) {
//				// TODO Auto-generated constructor stub
//			}
//
//			@SuppressWarnings("static-access")
//			public String GetMessages(){
//				
//				System.out.println(f.getG());
//				return f.getG();
//			}
		
		@SuppressWarnings("static-access")
		public void actionPerformed (ActionEvent e) {   
			  
			DatagramSendReceive r = new DatagramSendReceive();
			
			//action1 r1 = (action1) action11();
			
			String d = "192.168.1.104";
			
			JFrame frame2 = new JFrame(d);
		    frame2.setVisible(true);
		    frame2.setSize(200,200);
		    
		    @SuppressWarnings("resource")
			Scanner mr = new Scanner(System.in);
			System.out.println("This is my reply: ");
			String reply = mr.next();
			
			//message = reply;
			
			r.setMessage(reply);
	
			Thread t1 = new Thread(r);
			t1.start();
			
			//t1.
			
			//String f = r1.GetMessages();
		    
			JLabel label = new JLabel(reply + " : " + getG() ); 
		    JPanel panel = new JPanel();
		    frame2.add(panel);
		    panel.add(label);     
		    
		
		    
		  }

		//@SuppressWarnings("unused")
//		private Object action11(DatagramSendReceive r) {
//			// TODO Auto-generated method stub
//			return null;
//		}

		}

		
