import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Driver extends DatagramSendReceive{
	
	public static void main(String[] args) throws IOException {
		
		//  DatagramSendReceive r = DatagramSendReceive(); 		
		  JFrame frame = new JFrame("Message Application"); 
		  frame.setVisible(true);
		  frame.setSize(500,200);
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		  JPanel panel = new JPanel();
		  frame.add(panel);
		  JButton button = new JButton("Reply");
		  panel.add(button);
		  button.addActionListener (new action1());

		  JButton button2 = new JButton("Close");
		  panel.add(button2);
		  button2.addActionListener (new action2()); 
		}

//	private static DatagramSendReceive DatagramSendReceive() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	

}
