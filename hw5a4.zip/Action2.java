import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


class Action2 implements ActionListener {        
		  
	public void actionPerformed (ActionEvent e) { 
			  
			  System.exit(0);
	}
		
}   
